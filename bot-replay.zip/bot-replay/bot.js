const { 
    default: makeWASocket, 
    DisconnectReason, 
    useMultiFileAuthState,
    makeInMemoryStore,
    jidDecode
} = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs');

// 🗿 FUZZY REPLY SYSTEM (ikan = ada tuna!)
const REPLIES = {
    'ikan': '🐟 Ada tuna! 🐟',
    'tuna': '🐟 Fresh tuna ready!',
    'baju': '👕 Stock baju lengkap!',
    'harga': '💰 Cek DM untuk harga!',
    'order': '📦 Order diterima!',
    'done': '✅ Done bro!',
    'ok': '👍 Oke!',
    'halo': '🗿 Yo!',
    'menu': `
🗿 *REPLAY BOT MENU*
    
🐟 ikan/IKAN/tuna → Ada tuna!
👕 baju → Stock lengkap!
💰 harga → Cek DM!
📦 order → Order ok!
✅ done → Done bro!
👋 halo → Yo!
    
*Case insensitive & fuzzy match*`,
    'help': '❓ Ketik *menu*'
};

// Fuzzy search sederhana
function fuzzyMatch(text, keyword) {
    const t = text.toLowerCase().replace(/[^a-z0-9]/g, '');
    const k = keyword.toLowerCase().replace(/[^a-z0-9]/g, '');
    return t.includes(k) || k.includes(t);
}

console.log('🗿 Pterodactyl WA Replay Bot Starting...');

async function startBot() {
    // Auth folder untuk Pterodactyl
    const { state, saveCreds } = await useMultiFileAuthState('./auth');
    
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false, // Disable QR, pakai pairing
        logger: P({ level: 'silent' }),
        generateHighQualityLinkPreview: false,
        markOnlineOnConnect: true,
        // 🆕 PAIRING CODE MODE
        pairingCode: true
    });

    // 🆕 PAIRING CODE DISPLAY
    sock.ev.on('creds.update', saveCreds);
    
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr, pairingCode } = update;
        
        if (pairingCode) {
            console.log('\n🔗 *PAIRING CODE:*', pairingCode);
            console.log('📱 WhatsApp > Linked Devices > Link with phone number');
            console.log('📝 Masukkan kode 8 digit di atas!\n');
        }
        
        if (qr) {
            console.log('📱 Scan QR Code:');
            // QR terminal jika perlu
        }
        
        if (connection === 'close') {
            const code = lastDisconnect?.error?.output?.statusCode;
            console.log('🔄 Reconnect...', code);
            if (code !== DisconnectReason.loggedOut) {
                setTimeout(startBot, 3000);
            }
        }
        
        if (connection === 'open') {
            console.log('✅ Bot CONNECTED! Kirim "menu" untuk test');
            fs.writeFileSync('status.txt', '🟢 ONLINE');
        }
    });

    // 🗿 FUZZY REPLAY SYSTEM
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        
        const m = messages[0];
        if (!m.message || m.key.fromMe) return;

        const msgText = m.message.conversation || 
                       m.message.extendedTextMessage?.text || 
                       '';

        if (!msgText) return;

        const text = msgText.trim();
        console.log(`💬 Pesan: "${text}"`);

        // Cari match FUZZY (ikan/IKAN/IkAn semua match)
        const replyKey = Object.keys(REPLIES).find(key => 
            fuzzyMatch(text, key)
        );

        if (replyKey) {
            const reply = REPLIES[replyKey];
            await sock.sendMessage(m.key.remoteJid, { 
                text: reply 
            }, { 
                quoted: m 
            });
            
            console.log(`🗿 REPLY "${text}" → "${reply}"`);
            fs.appendFileSync('log.txt', `${new Date().toISOString()} | ${text} → ${reply}\n`);
        }
    });
}

// Anti crash Pterodactyl
process.on('unhandledRejection', (err) => {
    console.log('❌ Error:', err);
    setTimeout(startBot, 5000);
});

startBot();